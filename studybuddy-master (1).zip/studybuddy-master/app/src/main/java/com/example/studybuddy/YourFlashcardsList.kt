package com.example.studybuddy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.studybuddy.R

class YourFlashcardsList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.setContentView(R.layout.activity_your_flashcards_list)
    }
}