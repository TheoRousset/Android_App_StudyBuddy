package com.example.studybuddy

class FlashcardModel(var term: String, var definition: String)