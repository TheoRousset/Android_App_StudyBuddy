package com.example.studybuddy

class SetModel(var name: String, var id: String)